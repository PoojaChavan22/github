package com.emp.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.emp.bean.Employee;
import com.emp.controller.EmployeeController;

public class TestApps {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");	
		
		//EmployeeController employeeController = new EmployeeController();
		EmployeeController employeeController = (EmployeeController)ctx.getBean("employeeController");
		
		Employee emp = new Employee();
		emp.setEmployeeId(101);
		emp.setEmployeeName("Dhinchak");
		employeeController.sendEmployee(emp);
		System.out.println("Employee Added Successfully");
		
	}
	
}
