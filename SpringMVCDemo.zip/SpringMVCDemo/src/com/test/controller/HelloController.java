package com.test.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@RequestMapping("/alpha")
public class HelloController {

	@RequestMapping("/hello")
	public ModelAndView sayHello(@RequestParam("msg") String msg) // by default
																	// get
	{
		String str = msg;
		ModelAndView model = new ModelAndView("success", "message", str);
		/*
		 * model.setViewName("success"); model.addObject("message", str); //add
		 * data
		 */
		return (model);
	}

	//@RequestMapping("/show")
	public String showHomePage() {
		return ("index");
	}

	@RequestMapping(value = "/hello1", method = RequestMethod.POST)
	public String sayHello1(Model model) // returns view name
	{
		model.addAttribute("message", "Hello from Form");
		return ("success"); // success is view name
	}

}
